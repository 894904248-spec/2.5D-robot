# AGENTS.md — Instructions for Codex

You are working on a research MVP for a master's thesis project: **2.5D traversability-aware coverage navigation and recovery for a cleaning-robot-like four-wheel rover using a UAV-style high-level control concept**.

## Very important scope decision

Build the first version as **2D-core / 2.5D-ready**, not as a full 2.5D robotics simulator.

Meaning:
- The planner may run on a 2D grid of blocked/free/cost cells.
- Every cell and map object must already carry optional 2.5D fields: `height`, `slope`, `roughness`, `semantic`, `traversability_cost`.
- The public map API must expose these fields so a later version can replace the simple rules with LiDAR/camera-derived 2.5D traversability.
- Do not implement ROS, Gazebo, MAVLink, ArduPilot, SLAM, real LiDAR drivers, camera models, or deep learning in this MVP.

## Primary goal

Build the smallest runnable Python simulation that demonstrates:

1. A bounded cleaning area represented as a grid map.
2. A 2D occupancy-core planner with 2.5D-ready cell metadata.
3. A four-wheel ground robot abstraction that moves cell-by-cell.
4. Automatic area coverage using a simple serpentine/lawnmower or nearest-unvisited reachable target sequence.
5. Obstacle avoidance using A* over traversable cells.
6. A basic recovery/backtracking strategy: when the robot enters a dead end or the next path is blocked, retreat along known safe path history to the nearest position with an unvisited left/right/neighbor traversable branch, then replan.
7. Outputs: terminal metrics, final PNG visualization, CSV log, and optional animation.

## Do NOT overbuild

The first version is a thesis proof-of-concept scaffold, not a product simulator. Keep it easy to run on a normal laptop.

Do not add:
- ROS/Gazebo/MAVLink/ArduPilot
- SLAM or real localization
- real LiDAR or camera drivers
- neural networks
- dynamic physics
- multi-robot cooperation

## Required stack

Use Python 3.10+.
Prefer only: `numpy`, `matplotlib`, `pytest`.
Avoid heavy dependencies unless truly necessary.

## Required repository structure

```text
robot_2_5d_nav_sim/
  README.md
  requirements.txt
  src/
    robot_nav_sim/
      __init__.py
      map2d5.py
      planner.py
      robot.py
      simulator.py
      visualization.py
      metrics.py
  examples/
    run_mvp.py
  maps/
    baseline_room.json
    u_trap_room.json
    narrow_passage_room.json
  tests/
    test_planner.py
    test_simulator.py
  outputs/
```

## MVP behavior details

- The robot must never enter blocked cells.
- The implementation should compute traversability from 2.5D-ready fields, but the first maps may behave like ordinary 2D occupancy maps.
- Example rules:
  - `wall`, `hard_obstacle`, `pit`, `too_high`, `too_steep` -> blocked.
  - `carpet`, `low_bump`, `curtain_soft` -> traversable but with higher cost.
  - `floor` -> normal cost.
- Coverage target cells are reachable traversable cells.
- Use A* to move from current position to the next target.
- If no path to a target exists, mark target unreachable and continue.
- If movement gets blocked or no forward choices remain, perform recovery using safe path history:
  - Store every safely visited cell in order.
  - For each visited cell, record left/right/neighbor candidate cells that are traversable and unvisited.
  - On dead end, backtrack along the safe path to the nearest cell with an unvisited branch, then replan from there.
  - Count each recovery event.

## Acceptance criteria

Codex must run these before final answer:

```bash
python -m pip install -r requirements.txt
python examples/run_mvp.py --map maps/u_trap_room.json --output outputs/u_trap
pytest -q
```

The run must generate:
- `outputs/u_trap/final_map.png`
- `outputs/u_trap/path_log.csv`
- terminal metrics including coverage rate, steps, collision count, recovery count, unreachable targets.

Minimum acceptable metrics for the default U-trap scenario:
- `collision_count == 0`
- `coverage_rate >= 0.85` for reachable cells
- `recovery_count >= 1` in the U-trap scenario

## Coding style

- Clear, small modules.
- Type hints where practical.
- Deterministic behavior.
- README explains how the 2D-core can evolve into 2.5D.
- Keep the first implementation simple and robust.

## Research positioning

The later thesis can compare:
- 2D occupancy-only baseline
- 2D-core with 2.5D cost rules
- 2.5D traversability-cost planner
- 2.5D + recovery/backtracking planner

Do not claim this MVP solves real hardware deployment. It is a minimum verification platform.
