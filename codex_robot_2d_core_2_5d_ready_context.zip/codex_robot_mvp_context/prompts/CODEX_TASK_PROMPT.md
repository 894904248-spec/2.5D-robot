# Copy this whole prompt into Codex

Use `@find-skills` / `$find-skills` first. Search for skills suitable for:

- small Python package development
- test-driven implementation with pytest
- grid-based A* planning
- coverage path planning / lawnmower traversal
- simulator visualization with matplotlib
- CSV/PNG output generation

After selecting any useful skills, read `AGENTS.md` and all files under `docs/`, `maps/`, and `tests_expected/` first. Then build the smallest reproducible Python project for a **2D-core / 2.5D-ready cleaning robot navigation simulation**.

## Core decision

Do **not** implement a full 2.5D robotics simulator in the first version. Implement a 2D grid simulator first, but design the map schema and code API so every cell already supports 2.5D metadata:

- occupancy
- height
- slope
- roughness
- semantic class
- traversability cost

The first version may use mostly occupancy and semantic rules. Later versions will replace those rules with real 2.5D LiDAR/camera-derived traversability.

## Task

Create a runnable Python package named `robot_2_5d_nav_sim` that simulates a four-wheel rover / cleaning robot moving in a bounded grid space. The robot must cover reachable space while avoiding obstacles and recovering from dead ends using a safe-path left/right branch backtracking strategy.

## Research context

This is the first implementation step for a master's thesis direction: **2.5D traversability-aware coverage path planning and recovery for cleaning robots**. The platform is conceptually a cleaning robot simulator based on a four-wheel vehicle with a UAV-style high-level route-control core.

The first goal is not ROS/Gazebo. The first goal is a minimal local simulation that produces evidence that the algorithm idea works.

## Required features

1. Grid map with 2.5D-ready layers:
   - occupancy
   - height
   - slope
   - roughness
   - semantic class, e.g. floor, carpet, low_bump, curtain_soft, hard_obstacle, wall, pit
   - traversability cost

2. Traversability rules:
   - wall / hard_obstacle / pit / too_high / too_steep are blocked.
   - carpet / low_bump / curtain_soft are traversable but with increased cost.
   - floor is normal cost.

3. Coverage planning:
   - Generate target cells from all reachable traversable cells.
   - Prefer serpentine/lawnmower order or nearest-unvisited order.
   - Use A* between current robot cell and next target cell.
   - Skip unreachable target cells and count them.

4. Movement and obstacle avoidance:
   - Simulate step-by-step movement.
   - Do not enter blocked cells.
   - If the planned next cell becomes blocked or no route exists, trigger recovery.

5. Recovery strategy:
   - Maintain safe path history of visited cells.
   - For each visited cell, record left/right/neighbor branch candidates that are traversable and unvisited.
   - When in a dead end, backtrack along the safe path to the nearest branch candidate, then replan.
   - Count recovery events.
   - This corresponds to the first-stage “沿路左右标记法”: record possible side openings along the known safe route, then retreat to the nearest side opening instead of blindly turning.

6. Outputs:
   - terminal metrics
   - `outputs/<case>/final_map.png`
   - `outputs/<case>/path_log.csv`
   - optional `outputs/<case>/animation.gif` if easy

7. Tests:
   - `pytest -q` must pass.
   - Include tests for A*, traversability, no-collision, and recovery triggered in U-trap map.

## Required commands to pass

```bash
python -m pip install -r requirements.txt
python examples/run_mvp.py --map maps/u_trap_room.json --output outputs/u_trap
pytest -q
```

## Expected repository structure

```text
robot_2_5d_nav_sim/
  README.md
  requirements.txt
  src/
    robot_nav_sim/
      __init__.py
      map2d5.py
      planner.py
      robot.py
      simulator.py
      visualization.py
      metrics.py
  examples/
    run_mvp.py
  maps/
    baseline_room.json
    u_trap_room.json
    narrow_passage_room.json
  tests/
    test_planner.py
    test_simulator.py
  outputs/
```

## Implementation hints

Use simple JSON maps. For each map, define width, height, start, rectangular obstacles/features, and optional dynamic blocked cells. Convert rectangles into grid layers at load time.

Use 4-neighbor movement first. 8-neighbor can be added later.

A* cost formula can be:

```text
step_cost = 1.0 + traversability_cost(cell) + turn_penalty
```

Example traversability costs:

```text
floor = 1.0
carpet = 1.5
low_bump = 2.0
curtain_soft = 2.0
unknown = 3.0
blocked = infinity
```

Success metrics:

```text
coverage_rate = visited_reachable_cells / total_reachable_cells
collision_count = 0
recovery_count >= 1 for u_trap_room
```

## Development process

1. Use `@find-skills` / `$find-skills` first to discover helpful local skills.
2. Inspect all context files.
3. Create a concise implementation plan.
4. Implement the package.
5. Run the required commands.
6. Fix errors until tests pass.
7. Final response must summarize created files, how to run, and current limitations.

Do not add ROS/Gazebo/MAVLink/ArduPilot/SLAM/real sensors/deep learning in this MVP.
