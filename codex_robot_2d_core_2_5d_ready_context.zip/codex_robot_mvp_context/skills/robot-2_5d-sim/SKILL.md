---
name: robot-2_5d-sim
description: Use when building or modifying a minimal Python simulation for 2.5D traversability-aware cleaning robot coverage navigation, obstacle avoidance, and safe-path backtracking recovery. Do not use for ROS/Gazebo/hardware integration.
---

When this skill is used, build the smallest working Python project that simulates a cleaning robot on a 2.5D grid.

Follow these priorities:

1. Keep dependencies light: numpy, matplotlib, pytest.
2. Use JSON maps, not ROS maps.
3. Implement map layers: height, slope, roughness, semantic, cost, blocked.
4. Use A* for point-to-point movement over traversable cells.
5. Use serpentine/lawnmower ordering for coverage targets.
6. Implement safe-path branch backtracking recovery:
   - record safe visited cells,
   - mark neighboring unvisited branch candidates,
   - backtrack to the nearest safe cell with remaining branch candidate when blocked/dead-ended,
   - replan from there.
7. Generate metrics, CSV logs, and final PNG visualization.
8. Add pytest tests and run them.

Avoid adding ROS, Gazebo, ArduPilot, MAVLink, neural networks, or hardware drivers in the first MVP.
