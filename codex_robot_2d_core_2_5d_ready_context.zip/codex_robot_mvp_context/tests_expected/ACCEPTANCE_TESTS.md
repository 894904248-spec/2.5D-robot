# Expected tests Codex should implement

Codex should create real pytest files. At minimum:

## test_traversability_rules

- floor cell is traversable.
- wall/hard_obstacle/pit are blocked.
- carpet and low_bump are traversable but cost > floor.

## test_astar_finds_path

- On baseline_room map, A* finds a path from start to a reachable free cell.
- Returned path never enters blocked cells.

## test_simulator_no_collision

- Run baseline simulation.
- Assert collision_count == 0.

## test_recovery_triggered_in_u_trap

- Run U-trap simulation.
- Assert recovery_count >= 1.
- Assert coverage_rate >= 0.85.
- Assert collision_count == 0.
