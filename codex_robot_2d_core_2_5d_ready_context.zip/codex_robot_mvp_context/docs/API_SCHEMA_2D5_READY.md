# 2D-Core / 2.5D-Ready API Schema

The first implementation may plan on a 2D grid, but it must keep the following schema so the code can be upgraded to real 2.5D traversability later.

## Cell fields

Each grid cell should expose or be able to compute:

```python
@dataclass
class Cell:
    x: int
    y: int
    occupied: bool = False
    height: float = 0.0
    slope: float = 0.0
    roughness: float = 0.0
    semantic: str = "floor"
    traversability_cost: float = 1.0
```

## Required map methods

```python
class GridMap2D5:
    width: int
    height: int

    def in_bounds(self, cell: tuple[int, int]) -> bool: ...
    def cell(self, x: int, y: int) -> Cell: ...
    def neighbors4(self, cell: tuple[int, int]) -> list[tuple[int, int]]: ...
    def is_traversable(self, cell: tuple[int, int]) -> bool: ...
    def cost(self, cell: tuple[int, int]) -> float: ...
    def reachable_cells(self, start: tuple[int, int]) -> set[tuple[int, int]]: ...
```

## Traversability rule examples

```python
BLOCKED_SEMANTICS = {"wall", "hard_obstacle", "pit"}
SOFT_COSTS = {
    "floor": 1.0,
    "carpet": 1.5,
    "low_bump": 2.0,
    "curtain_soft": 2.0,
    "unknown": 3.0,
}
MAX_HEIGHT = 0.03
MAX_SLOPE = 15.0
MAX_ROUGHNESS = 0.04
```

For Stage 1, most cells can use default 2D values. The important point is that future Stage 2 maps can change `height`, `slope`, `roughness`, and `semantic` without rewriting A*, coverage, simulator, visualization, or tests.

## JSON map format

```json
{
  "name": "u_trap_room",
  "width": 30,
  "height": 20,
  "start": [2, 2],
  "defaults": {
    "semantic": "floor",
    "height": 0.0,
    "slope": 0.0,
    "roughness": 0.0
  },
  "rectangles": [
    {"semantic": "wall", "x": 0, "y": 0, "w": 30, "h": 1},
    {"semantic": "hard_obstacle", "x": 10, "y": 5, "w": 1, "h": 8},
    {"semantic": "carpet", "x": 3, "y": 10, "w": 6, "h": 4, "traversability_cost": 1.5}
  ]
}
```

## Metrics

The simulator should report:

```python
coverage_rate: float
visited_cells: int
total_reachable_cells: int
steps: int
collision_count: int
recovery_count: int
unreachable_targets: int
path_length: int
turn_count: int
```
