# 复杂度判断：建议第一版改成 2D-core / 2.5D-ready

## 结论

当前目标“2.5D扫地机器人寻路 + 全覆盖 + 避障 + 脱困 + 仿真程序”作为第一步略偏大。更合理的第一步是：

> **用 2D 栅格先跑通自动覆盖、A*避障、死胡同回退脱困；但地图数据结构一开始就预留 2.5D 字段。**

也就是：算法先按 2D 执行，数据结构按 2.5D 设计。

## 为什么不建议第一版直接做完整2.5D

完整2.5D会同时引入很多难点：

1. 高度、坡度、粗糙度如何从 LiDAR 点云生成；
2. 低矮障碍、软障碍、地毯、窗帘等语义如何定义；
3. 2.5D代价如何影响规划；
4. 脱困动作如何与真实车体动力学结合；
5. 可视化、测试、指标如何稳定复现。

这些问题同时做，容易导致 Codex 生成一个“看起来很大但很难验证”的项目。

## 第一版保留的研究价值

第一版只做 2D-core 并不等于研究退化成普通2D路径规划。关键是要保留下面三点：

1. **2.5D-ready map schema**：每个格子都有 height/slope/roughness/semantic/cost 字段；
2. **可通行性函数接口**：`is_traversable(cell)` 和 `traversability_cost(cell)` 一开始就独立出来；
3. **可替换实验组**：后续只需要替换 cost 规则，就可以比较 2D baseline 与 2.5D-aware planner。

## 推荐阶段划分

### Stage 1：2D-core MVP

目标：跑通闭环。

- JSON地图
- 2D occupancy
- A*寻路
- 覆盖目标选择
- U型陷阱/死胡同场景
- safe-path backtracking
- 输出 PNG/CSV/metrics
- pytest

### Stage 2：2.5D cost rules

目标：不接真实传感器，但加入模拟2.5D属性。

- height threshold
- slope threshold
- roughness cost
- semantic cost：carpet/low_bump/curtain_soft/hard_obstacle
- 对比 2D baseline 和 2.5D cost planner

### Stage 3：2.5D perception stub

目标：模拟 LiDAR/相机输入，但不做真实传感器。

- 从地图生成 fake lidar scan / local observation
- 局部更新 cost map
- 模拟未知障碍突然出现

### Stage 4：ROS/Gazebo 或真实小车

目标：把已验证的 planner 接到机器人系统。

- ROS node
- LiDAR map input
- real odometry
- 实车日志和视频

## 对 Codex 的一句话原则

> Do not build a full robotics stack. Build a small 2D grid navigation MVP whose map and planner API are already compatible with 2.5D traversability data.
