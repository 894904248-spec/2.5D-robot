# One-line prompts for Codex

## Recommended

```text
Use @find-skills / $find-skills first to find suitable local skills for Python simulation, pytest, grid A*, coverage planning, and visualization. Then read AGENTS.md and prompts/CODEX_TASK_PROMPT.md. Implement the 2D-core / 2.5D-ready cleaning robot navigation MVP, run python examples/run_mvp.py --map maps/u_trap_room.json --output outputs/u_trap and pytest -q, and fix all errors.
```

## Stricter minimal version

```text
Use @find-skills first. Build only a Python 2D grid MVP with a 2.5D-ready map schema. Do not add ROS/Gazebo/MAVLink/SLAM/deep learning. Implement A*, coverage, safe-path backtracking recovery, PNG/CSV output, and pytest tests.
```
