# Mapping from uploaded research materials to the MVP

## Traversability estimation paper

The traversability paper supports the idea that navigation needs both geometric cues and semantic cues. It notes that non-traversable regions may come from geometric hazards such as steep steps or abrupt elevation changes, and also from semantic constraints. For this MVP, we simplify that idea into a rule-based 2.5D grid layer: height, slope, roughness, semantic type, and traversability cost.

MVP mapping:

- LiDAR/camera multimodal perception -> simulated map attributes
- geometric hazards -> height/slope/roughness thresholds
- semantic constraints -> semantic cost/blocked rules
- dense traversability labels -> grid traversability map

## Cleaning robot CPP paper

The cleaning robot CPP paper emphasizes maximizing coverage rate and minimizing task execution time/turns. It also uses a framework involving SLAM, map preprocessing, and coverage path planning. For this MVP, SLAM is replaced by a given JSON map, and map preprocessing is simplified into obstacle inflation / traversability conversion.

MVP mapping:

- SLAM system -> given map file
- map preprocessor -> JSON feature rectangles -> grid layers
- coverage path planner -> serpentine target order + A*
- metrics -> coverage rate, steps, turns, recovery count

## Drone swarm / UAV control material

The drone material is useful because it already contains a high-level route-control idea: generate waypoints, send them one by one, detect blocked paths, and use safe-path backtracking. For the cleaning robot MVP, the UAV altitude and MAVLink details are removed; the route-control concept remains.

MVP mapping:

- Guided mode waypoint commands -> Python step-by-step target execution
- Serpentine CPP -> cleaning coverage target order
- blocked detection -> grid blocked / A* path unavailable
- safe-path backtracking -> recovery along visited safe cells
- Dijkstra safe graph -> optional later improvement; first MVP can backtrack by safe_path list
