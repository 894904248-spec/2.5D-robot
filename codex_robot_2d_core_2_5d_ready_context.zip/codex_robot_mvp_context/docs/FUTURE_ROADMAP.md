# Future Roadmap

## Stage 1 — 2D-core / 2.5D-ready MVP

- 2D grid occupancy simulator
- 2.5D-ready cell schema
- A* navigation
- coverage target selection
- safe-path branch backtracking
- PNG/CSV/metrics output
- pytest

## Stage 2 — Simulated 2.5D traversability

- height/slope/roughness thresholds
- semantic terrain classes
- cost-map comparison: 2D baseline vs 2.5D cost-aware
- scenarios: carpet edge, low bump, curtain, hard board, pit

## Stage 3 — Local perception stub

- fake local LiDAR observation from map
- local map update around robot
- unknown obstacle discovery during movement
- recovery after local discovery

## Stage 4 — ROS/Gazebo or real rover integration

- package planner as ROS node
- feed LiDAR/odometry map data
- log real trajectories
- compare simulation and hardware behavior

## Stage 5 — Thesis experiments

- metrics: coverage rate, task time proxy, path length, turn count, collision count, recovery count, repeated coverage, unreachable regions
- baseline comparisons: 2D-only, 2D+recovery, 2.5D-cost, 2.5D-cost+recovery
