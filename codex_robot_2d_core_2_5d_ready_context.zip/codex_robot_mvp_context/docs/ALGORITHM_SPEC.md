# Algorithm Specification

## 1. 2.5D map abstraction

A 2.5D map is represented as a regular 2D grid, but each cell stores vertical/geometric/semantic attributes:

```python
Cell = {
    "height": float,
    "slope": float,
    "roughness": float,
    "semantic": str,
    "blocked": bool,
    "cost": float,
}
```

The first MVP does not need point clouds. It should simulate the result of LiDAR/camera preprocessing.

## 2. Traversability rule

A simple rule-based function is enough:

```text
blocked = semantic in {wall, hard_obstacle, pit}
          or height > max_climb_height
          or slope > max_slope
```

Suggested values:

```text
max_climb_height = 2.5
max_slope = 20.0
```

Cost examples:

```text
floor: 1.0
carpet: 1.5
low_bump: 2.0
curtain_soft: 2.0
unknown: 3.0
blocked: infinity
```

## 3. A* planner

Use grid A* with Manhattan distance.

Neighbors: 4-neighbor first.

Cost:

```text
g_score[next] = g_score[current] + cell_cost[next]
```

Optional turn penalty:

```text
if previous_direction != new_direction:
    add 0.1 or 0.2
```

## 4. Coverage planner

Generate all traversable target cells in serpentine order:

```text
for y in range(height):
    xs = range(width) if y % 2 == 0 else reversed(range(width))
    for x in xs:
        if traversable(x, y): add target
```

Then iterate targets:

1. If already visited, skip.
2. Use A* from current to target.
3. If path exists, execute it step-by-step.
4. If path does not exist, trigger recovery or mark unreachable.

## 5. Safe-path branch recovery

Maintain:

```python
safe_path: list[tuple[int, int]]
branch_candidates: dict[tuple[int, int], set[tuple[int, int]]]
visited: set[tuple[int, int]]
```

After each safe step, update candidates around the current cell.

When blocked/dead-end:

```text
for cell in reversed(safe_path):
    remove already visited or currently blocked candidates
    if candidates remain:
        backtrack to cell along safe_path
        choose nearest/first candidate
        replan from cell to candidate
        recovery_count += 1
        break
else:
    report no recovery possible
```

This corresponds to the Chinese description: “沿路左右标记法，当进入死胡同时退回到左右非障碍的位置重新寻路”.

## 6. Metrics

- `reachable_cells`: flood fill from start over traversable cells.
- `visited_reachable_cells`: visited ∩ reachable_cells.
- `coverage_rate = len(visited_reachable_cells) / len(reachable_cells)`
- `collision_count`: attempted entry into blocked cells.
- `recovery_count`: number of backtracking recovery events.
- `unreachable_targets`: targets skipped because A* cannot find route.
