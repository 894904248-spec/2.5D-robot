# MVP 需求规格

## 输入

- JSON 地图文件
- 起点
- 地图宽高
- 障碍物和 2.5D 地形要素矩形定义

## 输出

- 覆盖率 coverage_rate
- 总步数 steps
- 碰撞次数 collision_count
- 脱困次数 recovery_count
- 不可达目标数 unreachable_targets
- 路径 CSV
- 最终地图 PNG

## 地图层

每个 cell 至少包含：

- `height`: 高度，单位可抽象为 cm 或归一化数值
- `slope`: 坡度风险
- `roughness`: 粗糙/摩擦风险
- `semantic`: 语义类别
- `blocked`: 是否不可通行
- `cost`: 通行代价

## 语义类别建议

- `floor`: 普通地面，可通行
- `carpet`: 地毯，可通行但高代价
- `low_bump`: 低坎，可通行但高代价
- `curtain_soft`: 软窗帘，可通行或谨慎通行
- `wall`: 墙，不可通行
- `hard_obstacle`: 硬障碍，不可通行
- `pit`: 凹坑，不可通行或极高代价
- `unknown`: 未知，高代价

## 覆盖策略

最小版本使用蛇形/牛耕式目标顺序：

1. 按 y 行扫描。
2. 偶数行从左到右，奇数行从右到左。
3. 对每个未覆盖且可通行 cell，调用 A* 规划过去。
4. 走到后标记覆盖。
5. 若不可达，跳过并计数。

## 脱困策略：沿路左右标记法

在机器人移动过程中：

1. 每走到一个安全 cell，将其加入 `safe_path_history`。
2. 检查它左、右、前、后邻居中未访问且可通行的 cell，加入该位置的 `branch_candidates`。
3. 如果当前目标无法继续、A* 找不到路、或进入死胡同：
   - 从 `safe_path_history` 逆序查找最近还有未访问候选分支的位置。
   - 沿历史路径回退到该位置。
   - 选择一个分支作为新目标或从该位置重新规划。
4. 如果没有任何分支，结束或报告剩余区域不可达。

## 验收标准

默认 U 型陷阱地图：

- 不能撞入 blocked cell。
- `collision_count == 0`
- `coverage_rate >= 0.85`
- `recovery_count >= 1`
- 程序可重复运行。
