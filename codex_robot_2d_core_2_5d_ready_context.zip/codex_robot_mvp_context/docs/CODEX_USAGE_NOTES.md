# Codex 使用建议

## 推荐方式一：Codex IDE / App

1. 新建一个空文件夹，例如 `robot_2_5d_nav_sim`。
2. 把本 zip 中的文件复制进去。
3. 用 VS Code / Cursor / Codex App 打开这个文件夹。
4. 打开 Codex 面板。
5. 粘贴 `prompts/CODEX_TASK_PROMPT.md` 全文。
6. 要求它先读 `AGENTS.md` 和 docs，再执行。

## 推荐方式二：Codex CLI

在项目根目录运行：

```bash
codex
```

然后粘贴：

```text
Read AGENTS.md and prompts/CODEX_TASK_PROMPT.md, then implement the MVP exactly. Run the required commands and fix errors until pytest passes.
```

## 使用 skills

Codex 官方支持 Skills，可以用 `/skills` 查看可用技能，也可以用 `$技能名` 显式调用。如果本机 Codex 没有 robotics 或 simulation skill，不要强行找；本包已经把上下文写入 `AGENTS.md` 和 prompt。

本包附带了一个可选技能草案：`skills/robot-2_5d-sim/SKILL.md`。如果你的 Codex 环境支持本地技能/插件，你可以把它安装到 Codex 的技能目录，或直接把里面内容复制进 prompt。
