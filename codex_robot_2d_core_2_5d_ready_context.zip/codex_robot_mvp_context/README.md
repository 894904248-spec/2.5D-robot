# Codex Context Package: 2D-Core / 2.5D-Ready Cleaning Robot Navigation MVP

This package is intended to be opened by Codex as project context. The first implementation should **not** attempt a full 2.5D robotics system. It should build a minimal, testable Python simulation with a 2D grid planner, while keeping the map data model ready for 2.5D fields.

## Recommended first command for Codex

Paste the following into Codex after extracting this folder:

```text
Use @find-skills / $find-skills first. Search for skills suitable for building a small Python simulation project with tests, grid-based A* planning, coverage path planning, and visualization. After selecting useful skills, read AGENTS.md and prompts/CODEX_TASK_PROMPT.md, then implement the MVP exactly as specified. Start with a 2D occupancy-core simulator, but design the map cell schema to include height, slope, roughness, semantic, and traversability_cost so it can be upgraded to 2.5D without changing the public API. Run python examples/run_mvp.py --map maps/u_trap_room.json --output outputs/u_trap and pytest -q, then fix all errors.
```

## Why 2D-core first

The research target remains 2.5D traversability-aware coverage and recovery. However, the first software step should avoid mixing too many hard problems: SLAM, real LiDAR, camera semantics, dynamic obstacles, ROS/Gazebo, and 2.5D terrain inference. The initial MVP should prove the control loop: coverage target selection → A* navigation → obstacle avoidance → safe-path backtracking recovery → metrics and visualization.

## Key files

- `AGENTS.md`: standing instructions for Codex.
- `prompts/CODEX_TASK_PROMPT.md`: direct build prompt.
- `prompts/CODEX_TASK_PROMPT_WITH_FIND_SKILLS.md`: direct prompt that explicitly starts with `find-skills`.
- `docs/COMPLEXITY_DECISION_ZH.md`: rationale for 2D-core / 2.5D-ready design.
- `docs/API_SCHEMA_2D5_READY.md`: required schema so future 2.5D can be plugged in.
- `maps/*.json`: starter scenarios.
- `tests_expected/ACCEPTANCE_TESTS.md`: acceptance criteria.
